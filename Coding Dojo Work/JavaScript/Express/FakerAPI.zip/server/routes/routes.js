const user = require(("./server.server.js"))
const app = require("../../app");

module.exports = (app) =>{
    app.get
}

app.get("api/user/new",(req,res)=>{
    const newfake = new user()

})