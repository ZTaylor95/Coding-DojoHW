const express = require("express")
const app = express();
const PORT =4000;
const {faker} = require("@faker-js/faker");



//---MiddleWare--
app.use(express.json());
app.use(express.urlencoded({extended: true}));
//-----------------

//-----import routes-----


app.listen(PORT, ()=> console.log("server is up on PORT",PORT))

const users =  [

    {password: faker.internet.password()},
    {email: faker.internet.email()},
    {phone: faker.phone.number()},
    {lastName: faker.name.lastName()},
    {firstName: faker.name.firstName()},
    {uui: faker.datatype.uuid()}
]


const company =  [

    {cid: faker.datatype.uuid()},
    {name: faker.company.name()},
    {address: faker.address.street()},
    {city: faker.address.city()},
    {zip: faker.address.zipCode()},
    {country: faker.address.country()}
]

app.post("/api/users", (req, res) => {
    console.log(req.body)
    users.push(req.body)
    users.json({
        message:"ok"
    })

})


app.get("/api/users", (req, res) => {
    res.json( users );
    })

app.get("/api/companies", (req, res) => {
    res.json( company );
})

app.get("/api/user/company", (req, res) => {
    res.json ({users, company}  )


})

