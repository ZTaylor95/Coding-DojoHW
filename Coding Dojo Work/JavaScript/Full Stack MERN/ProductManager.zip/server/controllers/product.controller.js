const Product = require("../models/product.model")

module.exports = {

    //read all
    findAll: (req, res) => {
        Product.find()
            .then(allDaProducts => {
                res.json(allDaProducts)
            })
            .catch(err => res.json(err))
    },

    //create
    create: (req, res) => {

        console.log(req.body)
        Product.create(req.body)
            .then(newProduct => {
                console.log("SERVER SUCCESS")
                res.json(newProduct)
            })
            .catch(err => {
                console.log("SERVER ERROR")
                //will edit this later maybe
                res.status(400).json(err)
            })
    },

    //read one
    findOne: (req, res) => {
        // Note.findOne({_id: req.params.id})
        Product.findById(req.params.id)
            .then(oneProduct => res.json(oneProduct))
            .catch(err => res.json(err))
    },

    //update
    update: (req, res) => {
        console.log("UPDATE ID", req.params.id)
        console.log("req.body", req.body)
        // Note.findOneAndUpdate({_id: req.params.id})
        Product.findByIdAndUpdate(req.params.id, req.body, {new:true, runValidators:true})
            .then(updatedProduct => res.json(updatedProduct))
            .catch(err => {
                    console.log("SERVER ERROR")
                    //will edit this later maybe
                    res.status(400).json(err)
            })
    },
    //delete
    delete: (req, res) => {
        // Note.deleteOne({_id: req.params.id})
        Product.findByIdAndDelete(req.params.id)
            .then(result => res.json(result))
            .catch(err => res.json(err))
    }

}