import axios from 'axios';
import React, {useState} from 'react';
import { useNavigate } from 'react-router-dom'

const Create = (props) => {

    const navigate = useNavigate();

    //form's state variable
    const [title, setTitle] = useState("")
    const [price, setPrice] = useState("")
    const [description, setDescription] = useState("")

    // const [title, setTitle] = useState("")
    // const [genre, setGenre] = useState("")
    // const [isImportant, setIsImportant] = useState(false)
//----------------------------------------------------------------//

    //db error array
    const [errors, setErrors] = useState([]);

    // const backHome = () => {
    //     navigate("/products")
    // }

    const createProduct = (e) => {
        e.preventDefault(e);


        axios.post("http://127.0.0.1:8000/api/products", {title,price,description})
            .then(res => {
                console.log("client success")
                console.log(res.data)

                // navigate("/products")
            })
            .catch(err => {
                console.log("client error")
                console.log(err)
                const errorResponse = err.response.data.errors; // Get the errors from err.response.data
                const errorArr = []; // Define a temp error array to push the messages in
                for (const key of Object.keys(errorResponse)) { // Loop through all errors and get the messages
                    errorArr.push(errorResponse[key].message)
                }
                // Set Errors
                setErrors(errorArr);
            })
        // for exam use axios.post("http://localhost:8000/api/products",{name,title,genre,isImportant})
    }
    return(
        <div>

            <div>
                {errors.map((err, index) => <p style={{color:"red"}} key={index}>{err}</p>)}
            </div>

            <form onSubmit={createProduct}>
                Title: <input onChange={e => setTitle(e.target.value)} value={title}/><br/><br/>
                Price: <input type={"number"} onChange={e => setPrice(e.target.value)} value={price}/><br/><br/>
                Description: <input onChange={e => setDescription(e.target.value)} value={description}/><br/><br/><br/>
                {/*title: <input onChange={e => setTitle(e.target.value)}   value={title} />     <br/>*/}
                {/*genre:<input onChange={e => setGenre(e.target.value)}   value={genre} />     <br/>*/}
                {/*important: <input type="checkbox" onChange={e => setIsImportant(e.target.checked)}   checked={isImportant} />     <br/>*/}
                {/*<button onClick=  {backHome}>cancel</button><br/><br/><br/>*/}
                <button>submit</button> <br/><br/><br/>
            </form>
        </div>
    )
}

export default Create