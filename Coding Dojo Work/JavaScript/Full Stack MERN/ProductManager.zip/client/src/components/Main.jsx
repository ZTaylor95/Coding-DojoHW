import {useEffect, useState} from "react";
import axios from "axios";

import productStyle from './Main.module.css'
import {Link, useNavigate} from "react-router-dom";
import Create from "./Create";

const Main = (props) => {


    const navigate = useNavigate()


    const [products, setProducts] = useState([])


// trigger when the component has finished loading

    useEffect(() => {
        // get all the products from our server

        axios.get("http://localhost:8000/api/products")
            .then(res => {
                console.log(res.data)
                setProducts(res.data)
            })
            .catch(err => {
                console.log(err)
            })
    }, [])

    //go to the update route
    const goToUpdate = (productMongoID) => {
        // console.log(productMongoID)
        navigate("/products/" + productMongoID + "/edit")
    }

        const goToViewOne = (productMongoID) => {
            // console.log(productMongoID)
            navigate("/products/" + productMongoID )
    }

    //Delete
    const deleteProduct = (deleteID) => {
        // if(window.confirm ("do it you wont")){

        axios.delete("http://localhost:8000/api/products/" + deleteID)
            .then(res => {
                console.log("delete success", res.data)
                setProducts(products.filter((product) => product._id !== deleteID))

                // remove from DOM after successful delete
            })
            .catch(err => console.log(err))

    }

    return (
        <fieldset>

            <legend>Main.jsx</legend>
            <div><Create/></div>
            {/*<div>{JSON.stringify(products)}</div>*/}
            {

                products.map((oneProduct) => {
                    return (

                        <div key={oneProduct._id} className={productStyle.product}>
                            {/*<Link to={`/products/${oneProduct._id}`}>*/}


                                <p>Title:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{oneProduct.title}</p>
                                <p>Price:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;${oneProduct.price}</p>
                                <p>Description: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{oneProduct.description}</p>

                                {/*<h5>{oneAuthor.title}</h5>*/}
                                {/*<h5>{oneAuthor.genre}</h5>*/}
                                {/*<h5>{oneAuthor.isImportant ? "📌" : ""}</h5>*/}
                            {/*</Link>*/}
                            <button onClick={() => goToViewOne(oneProduct._id)}>View</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <button onClick={() => goToUpdate(oneProduct._id)}>edit</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <button onClick={() => deleteProduct(oneProduct._id)}>delete</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </div>
                    )
                })
            }
        </fieldset>
    )
}

export default Main