import React, {useEffect,useState} from 'react';
import {useParams,useNavigate} from "react-router-dom";
import axios from "axios";

const Update = (props) => {

    const navigate = useNavigate()

    // grab the url variable :id
    const {id} = useParams()

    const [title,setTitle]=useState("")
    const [price,setPrice]=useState("")
    const [description,setDescription]=useState("")
    const [errors, setErrors] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:8000/api/products/"+ id)
            .then(res =>{
                console.log(res.data)
                setTitle(res.data.title)
                setPrice(res.data.price)
                setDescription(res.data.description)

            })
            .catch(err => console.log(err))
    },[id])


    const updateProduct = (e) =>{
        e.preventDefault();
            ///put request
        axios.put("http://localhost:8000/api/products/"+id,{title,price,description})
            .then(res=>{
                console.log(" clientSUCCES Baby")
                console.log(res.data)
                navigate("/products")
            })
            .catch(err => {
                console.log("client error")
                console.log(err)
                const errorResponse = err.response.data.errors; // Get the errors from err.response.data
                const errorArr = []; // Define a temp error array to push the messages in
                for (const key of Object.keys(errorResponse)) { // Loop through all errors and get the messages
                    errorArr.push(errorResponse[key].message)
                }
                // Set Errors
                setErrors(errorArr);
            })

        // for exam use axios.post("http://localhost:8000/api/products",{name,title,genre,isImportant})

    }


    return (
        <div>
            form state variables

            <div> {errors.map((err, index) => <p style={{color:"red"}} key={index}>{err}</p>)}</div>
            <form onSubmit={updateProduct}>
                title:  <input onChange={e => setTitle(e.target.value)}   value={title} />     <br/>
                price:  <input type={"number"} onChange={e => setPrice(e.target.value)}   value={price} />     <br/>
                description:  <input onChange={e => setDescription(e.target.value)}   value={description} />     <br/>
                {/*title: <input onChange={e => setTitle(e.target.value)}   value={title} />     <br/>*/}
                {/*genre:<input onChange={e => setGenre(e.target.value)}   value={genre} />     <br/>*/}
                {/*important: <input type="checkbox" onChange={e => setIsImportant(e.target.checked)}   checked={isImportant} />     <br/>*/}
                <button>submit</button>

            </form>
        </div>
    );
};

export default Update;
