import logo from './logo.svg';
import './App.css';
import {Link,Routes,Route,Navigate} from "react-router-dom";
import Main from "./components/Main";
import Create from "./components/Create";
import ViewOne from "./components/ViewOne";
import Update from "./components/Update";

function App() {
  return (
    <div className="App">
     <h1>Products Manager</h1>
        <Link to="/products">Home</Link> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <Link to="/create"></Link>

        <hr/>
        {/*Theater Stage*/}

        <Routes>

            {/*MAiN - All Authors*/}
            <Route path='/products' element={<Main/>}/>
            {/*Create*/}
            <Route path='/create' element={<Create/>}/>


            {/*ViewOne*/}
            <Route path="/products/:id" element={<ViewOne/>}/>
            {/*Update*/}
            <Route path='/products/:id/edit' element={<Update/>} />

            {/*Redirect*/}
            <Route path='*' element={<Navigate to="/products" replace/> }/>
        </Routes>
    </div>
  );
}

export default App;
