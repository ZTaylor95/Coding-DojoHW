import logo from './logo.svg';
import './App.css';
import {Link,Routes,Route,Navigate} from "react-router-dom";
import Main from "./components/Main";
import Create from "./components/Create";
import ViewOne from "./components/ViewOne";
import Update from "./components/Update";

function App() {
  return (
    <div className="App">
     <h1>Authors</h1>
        <Link to="/authors">Home</Link> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <Link to="/create">Create</Link>

        <hr/>
        {/*Theater Stage*/}

        <Routes>

            {/*MAiN - All Authors*/}
            <Route path='/authors' element={<Main/>}/>
            {/*Create*/}
            <Route path='/create' element={<Create/>}/>


            {/*ViewOne*/}
            <Route path="/authors/:id" element={<ViewOne/>}/>
            {/*Update*/}
            <Route path='/authors/:id/edit' element={<Update/>} />

            {/*Redirect*/}
            <Route path='*' element={<Navigate to="/authors" replace/> }/>
        </Routes>
    </div>
  );
}

export default App;
