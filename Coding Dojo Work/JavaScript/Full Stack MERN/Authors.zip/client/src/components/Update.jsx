import React, {useEffect,useState} from 'react';
import {useParams,useNavigate} from "react-router-dom";
import axios from "axios";

const Update = (props) => {

    const navigate = useNavigate()

    // grab the url variable :id
    const {id} = useParams()

    const [name,setName]=useState("")

    useEffect(() => {
        axios.get("http://localhost:8000/api/authors/"+ id)
            .then(res =>{
                console.log(res.data)
                setName(res.data.name)

            })
            .catch(err => console.log(err))
    },[id])


    const updateAuthor = (e) =>{
        e.preventDefault();
            ///put request
        axios.put("http://localhost:8000/api/authors/"+id,{name})
            .then(res=>{
                console.log(" clientSUCCES Baby")
                console.log(res.data)
                navigate("/authors")
            })
            .catch(err=>{
                console.log("LMAO CLIENT FAILURE")
                console.log(err)
            })

        // for exam use axios.post("http://localhost:8000/api/authors",{name,title,genre,isImportant})

    }


    return (
        <div>
            form state variables
            <form onSubmit={updateAuthor}>
                name:  <input onChange={e => setName(e.target.value)}   value={name} />     <br/>
                {/*title: <input onChange={e => setTitle(e.target.value)}   value={title} />     <br/>*/}
                {/*genre:<input onChange={e => setGenre(e.target.value)}   value={genre} />     <br/>*/}
                {/*important: <input type="checkbox" onChange={e => setIsImportant(e.target.checked)}   checked={isImportant} />     <br/>*/}
                <button>submit</button>

            </form>
        </div>
    );
};

export default Update;
