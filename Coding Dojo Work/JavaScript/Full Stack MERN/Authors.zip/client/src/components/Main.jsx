import {useEffect, useState} from "react";
import axios from "axios";

import authorStyle from './Main.module.css'
import {Link, useNavigate} from "react-router-dom";

const Main = (props) => {


    const navigate = useNavigate()


    const [authors, setAuthors] = useState([])


// trigger when the component has finished loading

    useEffect(() => {
        // get all the authors from our server

        axios.get("http://localhost:8000/api/authors")
            .then(res => {
                console.log(res.data)
                setAuthors(res.data)
            })
            .catch(err => {
                console.log(err)
            })
    }, [])

    //go to the update route
    const goToUpdate = (authorMongoID) => {
        // console.log(authorMongoID)
        navigate("/authors/" + authorMongoID + "/edit")
    }

    //Delete
    const deleteAuthor = (deleteID) => {
        if(window.confirm ("do it you wont")){

        axios.delete("http://localhost:8000/api/authors/" + deleteID)
            .then(res => {
                console.log("delete success", res.data)
                setAuthors(authors.filter((author) => author._id !== deleteID))

                // remove from DOM after successful delete
            })
            .catch(err => console.log(err))
        }
    }

    return (
        <fieldset>

            <legend>Main.jsx</legend>
            {/*<div>{JSON.stringify(authors)}</div>*/}
            {

                authors.map((oneAuthor) => {
                    return (
                        <div key={oneAuthor._id} className={authorStyle.author}>
                            <Link to={`/authors/${oneAuthor._id}`}>


                                <p>{oneAuthor.name}</p>

                                {/*<h5>{oneAuthor.title}</h5>*/}
                                {/*<h5>{oneAuthor.genre}</h5>*/}
                                {/*<h5>{oneAuthor.isImportant ? "📌" : ""}</h5>*/}
                            </Link>
                            <button onClick={() => goToUpdate(oneAuthor._id)}>edit</button>
                            <button onClick={() => deleteAuthor(oneAuthor._id)}>delete</button>
                        </div>
                    )
                })
            }
        </fieldset>
    )
}

export default Main