import axios from 'axios';
import React, {useState} from 'react';
import { useNavigate } from 'react-router-dom'

const Create = (props) => {

    const navigate = useNavigate();

    //form's state variable
    const [name, setName] = useState("")

    // const [title, setTitle] = useState("")
    // const [genre, setGenre] = useState("")
    // const [isImportant, setIsImportant] = useState(false)
//----------------------------------------------------------------//

    //db error array
    const [errors, setErrors] = useState([]);

    const backHome = () => {
        navigate("/authors")
    }

    const createAuthor = (e) => {
        e.preventDefault();


        axios.post("http://127.0.0.1:8000/api/authors", {name})
            .then(res => {
                console.log("client success")
                console.log(res.data)
                navigate("/authors")
            })
            .catch(err => {
                console.log("client error")
                console.log(err)
                const errorResponse = err.response.data.errors; // Get the errors from err.response.data
                const errorArr = []; // Define a temp error array to push the messages in
                for (const key of Object.keys(errorResponse)) { // Loop through all errors and get the messages
                    errorArr.push(errorResponse[key].message)
                }
                // Set Errors
                setErrors(errorArr);
            })
        // for exam use axios.post("http://localhost:8000/api/authors",{name,title,genre,isImportant})
    }
    return(
        <div>

            <div>
                {errors.map((err, index) => <p style={{color:"red"}} key={index}>{err}</p>)}
            </div>

            <form onSubmit={createAuthor}>
                name: <input onChange={e => setName(e.target.value)} value={name}/>
                {/*title: <input onChange={e => setTitle(e.target.value)}   value={title} />     <br/>*/}
                {/*genre:<input onChange={e => setGenre(e.target.value)}   value={genre} />     <br/>*/}
                {/*important: <input type="checkbox" onChange={e => setIsImportant(e.target.checked)}   checked={isImportant} />     <br/>*/}
                <button onClick={backHome}>cancel</button>
                <button>submit</button>
            </form>
        </div>
    )
}

export default Create