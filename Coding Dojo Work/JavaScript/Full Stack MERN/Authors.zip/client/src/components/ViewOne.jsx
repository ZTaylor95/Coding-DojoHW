import React, {useEffect, useState} from "react";
import {useParams} from "react-router-dom";
import axios from "axios";

const thisComponentStyle ={
    width: "60%",
    textAlign: "left",
    margin: "0 auto",
    padding: "10px 20px",
    backgroundColor: "#61dafb",
    borderRadius: "10px"
}

const ViewOne = (props) => {
  const {id} = useParams()


  const [thisAuthor,setThisAuthor] = useState(null)


  useEffect(() => {
    axios.get("http://localhost:8000/api/authors/"+ id)
        .then(res =>{
          console.log(res.data)
          setThisAuthor(res.data)
        })
        .catch(err => console.log(err))
  },[id])

  return(
      <div>
        {
          thisAuthor ? (
              <div style={thisComponentStyle}>
                {thisAuthor.name}
                </div>
          ) : "loading"

        }
      </div>
  )
}

export default ViewOne