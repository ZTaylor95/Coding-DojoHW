const Author = require("../models/author.model")

module.exports = {

    //read all
    findAll: (req, res) => {
        Author.find()
            .then(allDaAuthors => {
                res.json(allDaAuthors)
            })
            .catch(err => res.json(err))
    },

    //create
    create: (req, res) => {

        console.log(req.body)
        Author.create(req.body)
            .then(newAuthor => {
                console.log("SERVER SUCCESS")
                res.json(newAuthor)
            })
            .catch(err => {
                console.log("SERVER ERROR")
                //will edit this later maybe
                res.status(400).json(err)
            })
    },

    //read one
    findOne: (req, res) => {
        // Note.findOne({_id: req.params.id})
        Author.findById(req.params.id)
            .then(oneAuthor => res.json(oneAuthor))
            .catch(err => res.json(err))
    },

    //update
    update: (req, res) => {
        console.log("UPDATE ID", req.params.id)
        console.log("req.body", req.body)
        // Note.findOneAndUpdate({_id: req.params.id})
        Author.findByIdAndUpdate(req.params.id, req.body, {new:true, runValidators:true})
            .then(updatedAuthor => res.json(updatedAuthor))
            .catch(err => res.json(err))
    },
    //delete
    delete: (req, res) => {
        // Note.deleteOne({_id: req.params.id})
        Author.findByIdAndDelete(req.params.id)
            .then(result => res.json(result))
            .catch(err => res.json(err))
    }

}