const express = require("express");
const app = express();
const PORT = 8000;
const DB = "jokes"


app.use(express.json(), express.urlencoded({extended: true}));


const AllMyJokeRoutes = require("./routes/jokes.routes");
AllMyJokeRoutes(app);

require("./config/mongoose.config")(DB)



app.listen(PORT, () => console.log(`server up on ${PORT}`));