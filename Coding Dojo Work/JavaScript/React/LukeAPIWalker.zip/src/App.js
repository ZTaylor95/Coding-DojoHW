import React from "react";
import Main from "./components/Main";
import './App.css';
import People from "./components/People";
import Other from "./components/Other";
import ErrorPage from "./components/ErrorPage";
import Planet from "./components/Planet";
import Form from "./components/Form";
import {
    Routes,
    Route,
    Link


} from "react-router-dom";


function App() {
    return (
        <div className="App">


            {/*<>Route</> <br/>*/}

            <fieldset>
                {/*<Link to={"/"}>Link Home</Link> <br/>*/}
                {/*<Link to={"/other"}>Other</Link><br/>*/}
                {/*<legend>Routes component</legend>*/}
                <Routes>

                    <Route path="/" element={<Main/>}/>
                    <Route path='/form' element={<Form/>}/>
                    <Route path="/people/:pId" element={<People/>}/>
                    <Route path="/planets/:varId" element={<Planet/>}/>

                    {/*<Route path={"/other"} element={*/}
                    {/*    <>*/}
                    {/*    <Other/>*/}

                    {/*</>*/}
                    {/*}/>*/}
                    {/*<Route path={"*"} element={<ErrorPage/>}/>*/}

                </Routes>
            </fieldset>
        </div>
    );
}

export default App;
