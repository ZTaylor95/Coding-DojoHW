import React from "react";
import {useState} from "react";
import {useNavigate} from "react-router-dom";
import Main from "./Main";

const objects = [
    "people",
    "planets"

]

const Form = (props) => {
    const navigate = useNavigate();
    const [peopleNum, setPeopleNum] = useState(1)
    const [object, setObjectType] = useState("people")

    const submitHandler = (e) => {
        e.preventDefault();
        console.log(object)
        navigate('/' + object + '/' + peopleNum)

    }

    return (
        <div>
            <form onSubmit={submitHandler}>
                Enter Id
                <input type="text" onChange={e => setPeopleNum(e.target.value)}/>
                <select value={object} onChange={e => setObjectType(e.target.value)}>
                    {objects.map((object, idx) =>
                        <option key={idx} value={object}>{object}</option>
                    )}
                </select>

                <button>Submit</button>
            </form>
        </div>
    )
}
export default Form