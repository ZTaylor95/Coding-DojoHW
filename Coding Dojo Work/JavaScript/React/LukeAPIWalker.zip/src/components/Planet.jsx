import React, {useState} from "react";
import {useParams} from "react-router-dom";
import {useEffect} from "react";
import axios from "axios";
import Form from "./Form";




const Planet = (props) => {
    const [planet, setPlanet] = useState({})
    const {varId} = useParams();

    useEffect(() => {
        axios.get(`https://swapi.dev/api/planets/${varId}`)
            .then((apiResponse) => {
                console.log(apiResponse.data);
                setPlanet(apiResponse.data)
            })
            .catch(error => console.log("error", error))
    }, [varId])

    return (
       <div><Form/>

        <div>

           <h2> Planet: {planet.name}</h2> <br/>
            <h3>Climate: {planet.climate}</h3>
            <h3>Terrain: {planet.terrain}</h3>
            <h3>Surface Water: {planet.surface_water} </h3>
            <h3>Population: {planet.population}</h3>
            {/*Id:{varId}*/}
        </div>
       </div>
    )
}
export default Planet