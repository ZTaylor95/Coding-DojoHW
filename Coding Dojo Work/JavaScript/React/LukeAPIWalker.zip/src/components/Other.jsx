import React from "react";

const Other = (props) => {
    return (
        <fieldset>
           <legend>Other.jsx</legend>
            <h2>hello other</h2>
        </fieldset>
    )
}

export default Other