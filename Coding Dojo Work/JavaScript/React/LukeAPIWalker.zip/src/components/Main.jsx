import React from "react";

const Main = (props) => {
    return (
        <fieldset>
            <legend>Main.jsx</legend>
<h2>Home</h2>
        </fieldset>
    )
}

export default Main