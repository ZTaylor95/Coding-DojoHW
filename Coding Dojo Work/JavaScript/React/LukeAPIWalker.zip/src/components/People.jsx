import React, {useState} from "react";
import {Route, Routes, useParams} from "react-router-dom";
import {useEffect} from "react";
import axios from "axios";
import Form from "./Form";


const People = (props) => {
    const [people, setPeople] = useState({})
    const {pId} = useParams();

    useEffect(() => {
        axios.get(`https://swapi.dev/api/people/${pId}`)
            .then((apiResponse) => {
                console.log(apiResponse.data);
                setPeople(apiResponse.data)
            })
            .catch(error => console.log("error", error))
    }, [pId])

    return (
        <div><Form/>
            <div>

                <h2> Name: {people.name}</h2> <br/>
                <h3>Height: {people.height + " cm"} </h3>
                <h3>Mass: {people.mass + " kg"} </h3>
                <h3>Hair Color: {people.hair_color} </h3>
                <h3>Skin Color: {people.skin_color} </h3>


            </div>
        </div>


    )
}
export default People