import './App.css';
import {useState} from 'react'
import axios from 'axios';

function App() {

    const [pokemons, setPokemons] = useState([])

    const fetchPokemon = () => {

        axios.get("https://pokeapi.co/api/v2/pokemon?limit=807offset=0/type")
            .then((res) => {
                console.log(res.data)
                setPokemons(res.data.results)
                console.log(typeof pokemons)
            })
            .catch(error => console.log(error))
    }
    return (

        <div className="App">

            <button className={"margin"} onClick={fetchPokemon}>Fetch Pokemon</button>
            <hr/>

            <div >

                <h1>Name:</h1>

                {
                    pokemons.map((pokemon, i) => {
                        console.log(pokemon)
                        return (
                            <ul>

                            <li>
                                {pokemon.name.charAt(0).toUpperCase() + pokemon.name.slice(1)}
                            </li>
                            </ul>

                        )
                    })
                }
            </div>


        </div>

    );
}

export default App;