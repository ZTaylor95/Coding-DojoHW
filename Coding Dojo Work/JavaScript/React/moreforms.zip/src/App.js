
import './App.css';

import Display from "./components/display";


function App() {
    const users = ["firstName", "lastName", "email", "password", "confirm"]
  return (
    <div className="App">
      <Display users={users} />
    </div>
  );
}

export default App;
