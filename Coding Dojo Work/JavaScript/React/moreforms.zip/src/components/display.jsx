import React, {useRef} from "react";

const Display = (props) => {
    console.log(props.users)
    return (
    <fieldset>

        {props.users.map(() =>{

        )}

        }

    </fieldset>


    )

}

export default Display