import React, {useState} from "react";
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Button from 'react-bootstrap/Button';



function App() {
    const [newTodo, setNewTodo] = useState("");
    const [todos, setTodos] = useState([]);

    const handleNewTodoSubmit = (e) => {
        e.preventDefault(e);
        if ( newTodo.length === 0 ) {
            return
        }
        const  todoItem = {
            text: newTodo,
            complete: false
        };
        setTodos([...todos,todoItem ])
        setNewTodo("");
    };
    const handleTodoDelete = (delIdx) => {
        const filteredTodos = todos.filter((todo, i) => {
            return i !== delIdx;
        });
        setTodos(filteredTodos);
    };
    const handleToggleComplete=(idx)=>{
        const updateTodos = todos.map((todo,i) =>{
            if ( idx === i ) {
                todo.complete = !todo.complete;
            }
            return todo;
        });
        setTodos(updateTodos);
    }
    return (
        <div style={{textAlign: "center"}}>
            <form onSubmit={(e) => {
                handleNewTodoSubmit(e);
            }}>
                <input onChange={(e) => {
                    setNewTodo(e.target.value);
                }} type="text"
                       value={newTodo}
                />
                <div>
                    <button variant="secondary"> Add</button>
                </div>
            </form>
            <hr/>

            {todos.map((todo, i) => {
                    const todoClasses =["bold"];
                    if (todo.complete) {
                        todoClasses.push();
                    }
                    return (
                        <div key={i}>
                            <span style={{textDecoration: todo.complete ? "line-through":"none"} }> {todo.text}</span>
                            <input  onChange={(e)=>{

                             handleToggleComplete(i);
                            }} checked={todo.complete} type= "checkbox"/>
                            <Button variant="primary" onClick={(e) => {
                                handleTodoDelete(i);
                            }}
                                    style={{marginLeft: "20px"}}
                            >
                                Delete
                            </Button>
                            {/*{JSON.stringify(todo)}*/}
                        </div>
                    );
                })}

        </div>
    );
}

export default App;
