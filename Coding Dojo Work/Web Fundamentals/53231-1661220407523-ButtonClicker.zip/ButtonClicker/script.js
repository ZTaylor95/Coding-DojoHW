function custom() {;
}


function turnOff(element) {
    element.innerText = "Sign in" ;
}


function hide(element) {
    element.remove();
}







