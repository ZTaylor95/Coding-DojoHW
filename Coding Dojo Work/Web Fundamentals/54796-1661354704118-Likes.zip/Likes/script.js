function updateLikes(element) {
    document.getElementById(element).innerText = parseInt(document.getElementById(element).innerText) + 1;
}